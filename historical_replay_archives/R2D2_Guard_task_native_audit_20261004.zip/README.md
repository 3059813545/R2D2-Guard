# Private task-native reviewer evidence

S17 and Main Table III: 1,400 new generations, 520 reused candidates, 180 questions.
The inner formal archive is unchanged; its pending-audit status is a historical snapshot.
The two LOCAL audit files record completed CPU checks.

After extracting to a new folder, use Python 3 with NumPy (verified with 2.3.5):
python audit_formal_evidence.py
python audit_actions_and_residuals.py
The helpers intentionally refuse to overwrite existing LOCAL_*.json; preserve the
provided reports and run the helpers in a separate fresh copy with those two
generated report files omitted. Compare fresh reports with the supplied reports.
No GPU, server, model weights, network, retraining or generation is required.
The first helper uses archived function bodies for parsing/summary rebuilding;
the second action helper states explicit rules rather than importing the driver.

pilot_evidence/ retains the separate 220+152 prompt-development generations,
their older CPU audit and manual QA. They are not added to the formal sample size.

JSONL = raw events/requests/cases/decisions; JSON = protocols, analyses and QA.
Selection counts use all questions in the specified split, not accepted-only
accuracy. Bootstrap intervals are fixed-pool descriptive intervals.
Benchmark labels are not independent factual certificates.

The inner archive includes the registered benign training input solely for overlap
checks. Full base/adapter weights are omitted and remain identified by recorded
digests; omitted payloads cannot be independently verified from this package.
This is private reviewer evidence, not a public deposit, redistribution licence,
complete training replication or service-delivery validation. Authors must
confirm sharing permissions and the actual portal attachment role.
