# Reviewer replay: supplementary results and source-label correction

This is a private submission evidence package, not a public repository release.
Run `python verify_extension_and_corrections.py` in a Python environment with
NumPy. It checks hashes, replays the original frozen archive on a temporary copy,
reconstructs source-corrected historical results, and audits all 5,072 additional
raw completions and their paired intervals. No server, GPU, model weights, or
network are required for this verification.

The original archive preserves frozen labels and scores. The correction layer
joins authoritative source answers by question identity. It changes no model
response, answer extractor, routing, release action, attack target count, timing,
or receipt. The 94 new clean questions are disjoint from audited historical
occurrences, not guaranteed pretraining-free or semantically independent. The
92 triggered identities exclude two source-gold-equals-target questions; seeds
reuse the same question identities. Prompt sensitivity is separately frozen
after observing the first solver run, and remains exploratory.

The extension preserves exact inputs and attack-bearing extensions for private
review, plus outputs, protocol snapshots, and configuration digests. Deployable
weights, poisoned training data, complete base-weight provenance, retraining,
and fresh model-output regeneration are not supplied. Authors must approve
public redistribution and verify model/data licensing; no unrestricted license
or public accession is asserted.
