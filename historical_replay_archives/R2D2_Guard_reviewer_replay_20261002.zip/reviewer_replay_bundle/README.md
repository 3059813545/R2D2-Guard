# Reviewer replay bundle

This bundle accompanies the main manuscript and supplementary material dated
2026-10-01, with the fresh utility/evidence revision completed 2026-10-02. It is a CPU-only response-decision replay package.

## Run

Extract the ZIP, enter reviewer_replay_bundle, and run:

    python replay_submission.py .

Python 3.10 or later is sufficient. No third-party packages, network access,
GPU, model files, or server paths are required. The entry point checks SHA-256
integrity, reconstructs 2,040 core records, 680 full-request replacement records,
680 local scrutiny records, full-request agreement and two-response consistency,
23 historical E5/M10b ledgers, 900 primary pairs, and 26 decimal-parser boundaries.
It writes replay_output/REPLAY_REPORT.json and REPLAY_ENDPOINT_COUNTS.csv.
Historical replay runs on a temporary copy so preserved source files are unchanged.
Twenty paired bootstrap intervals and 24 timed policy groups are recomputed.
The final revision additionally reconstructs eight exploratory paired contrasts,
clean recovery/call counts, 680 byte-identical candidate/solver pairs across the
core and full-request stages, and 20 finite-pool inspection-budget bounds.
Historical verifier harnesses differ: the replay report lists three Llama
responses whose recorded answer differs from new strict end-anchored extraction.
Historical endpoints preserve their frozen verifier answers; new service
responses are fully reparsed under their own frozen strict protocol.

The terminology ledger maps descriptive manuscript names to unchanged raw policy
IDs. Figure source-data CSV files reproduce the displayed clean partitions and
pass-side audit counts. Their addition changes no model output or decision.

## Contents and limits

Raw completion text, numeric gold/target labels, stable identities, policy
records, decision journals, local receipts, and configuration digests are retained.
The seven-policy endpoint counts exactly match TABLE_SOURCE_COUNTS.json, used
to generate the manuscript's new endpoint tables. Historical source hashes and
training metadata are preserved as provenance records.

archived_analysis_sources preserves the original analysis/service code, model
prompts, ordering rules, and comparison specifications. Some of these original
scripts refer to the research server or external libraries. They are provenance
sources, not the portable replay entry point.

The minimal bundle omits deployable weights, poisoned training corpora, raw
attack-bearing input extensions, and full decoder traces. It supports response
decision reconstruction, not adapter retraining or fresh output generation.
Historical trace-ranking/holdout diagnostics are retained as summary evidence;
the entry point does not reconstruct all old AUROCs from decoder probabilities.
Receipt checks refer to local files, not delivery to an external user. File hashes
detect accidental modification but cannot prove a compromised logger is truthful.
Repeated questions across policies/seeds are not independent new observations.

The submission manifest lists every preserved source file. Derived replay_output
files are excluded. The original audit_pack/MANIFEST.json records historical
source provenance; SUBMISSION_MANIFEST.json checks the transported files.


## Fresh matched-instruction utility evidence

adapter_utility/ preserves 1,600 newly generated clean completions across four
model/adapter arms on 300 GSM8K and 100 SVAMP questions. The protocol was frozen
before generation. All arms receive the same per-question semantic instruction;
Math7B uses raw prompts and Instruct14B its native chat template. This is a new
batched protocol using existing seed-42 adapters and reused clean question pools.
No serial timing, attack rate, or independent holdout claim follows from it.

The CPU entry point reparses every completion, checks prompt/script/parser hashes,
reconstructs counts and ten paired bootstrap contrasts, and checks a 400-record
post hoc clean-model field-wrapper replay. The wrapper uses predicted answers,
never gold, and adds no model calls. It meets only the minimal selected-field
schema, not an authentic worked-calculation requirement.

RETENTION_AUDIT.json separately identifies eight correct original answers retained
by conditional verification but not correctly delivered by the prior clean-solver
policy. One was a strict parsing failure, and seven were wrong solver numbers.
These cases are fixed-output complementarity evidence, not proof of a private
adapter skill, universal necessity, or a deployable oracle answer selector.

prompt_clarification/ adds 320 new completions under a separately frozen
exploratory clarification protocol. It was motivated by observed placeholder and
empty-marker failures in the initial run. The same explicit numeric format example
is supplied to all four arms on the first 40 questions per task in the original
SHA order. Exact subset identities and original prompt prefixes are checked.
The CPU entry point reconstructs ten additional contrasts and 80 additional
formatting replays. These reused subsets are not pooled as independent questions.
