# Frozen E5 and M10b audit package

Run `python replay_audit.py replay .` in this directory. Only the Python standard
library is required. The command reparses retained model responses, checks frozen
route decisions, replays contract-direct-block and the archived strict-Qwen policy,
checks action conservation and reconstructs `REBUILT_ENDPOINTS.json`.

`S5D_POOLED_REBUILT.json` reconstructs the three pooled published S5d rows.
`PUBLISHED_TABLE_CHECKS.json` compares those counts with the manuscript.
`MANIFEST.json` records source and output hashes. Model weights, raw prompts,
training data and GPU libraries are not needed for this decision replay.

This package preserves raw response text and is private pending disclosure review.
Gold answers are drawn from the frozen input source, since some old scored ledgers
have an empty gold field. This is not an independent rerun of training, generation,
or historical external delivery. Training seeds sharing a question are not new
independent questions. Missing historical delivery receipts remain explicitly
missing; a replayed RELEASE action does not invent a delivery receipt.
